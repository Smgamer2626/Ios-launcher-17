const $=id=>document.getElementById(id);
const lock=$('lockscreen'),home=$('home'),cc=$('controlCenter'),toast=$('toast');
let unlocked=false,ccOpen=false;
function time(){const d=new Date();let h=d.getHours()%12||12,m=String(d.getMinutes()).padStart(2,'0');let t=`${h}:${m}`;$('statusTime').textContent=t;$('clockText').textContent=t;const opts={weekday:'long',month:'long',day:'numeric'};let date=d.toLocaleDateString(undefined,opts);$('dateText').textContent=date;$('ccDate').textContent=date;$('homeDate').textContent=d.getDate();}
time();setInterval(time,10000);
function say(msg){toast.textContent=msg;toast.classList.remove('hidden');setTimeout(()=>toast.classList.add('hidden'),1500)}
function unlock(){unlocked=true;lock.classList.add('hidden');home.classList.remove('hidden');}
function lockPhone(){unlocked=false;ccOpen=false;cc.classList.add('hidden');home.classList.add('hidden');lock.classList.remove('hidden')}
function openCC(){ccOpen=true;cc.classList.remove('hidden')}
function closeCC(){ccOpen=false;cc.classList.add('hidden')}
let startY=0;
document.addEventListener('touchstart',e=>{startY=e.touches[0].clientY},{passive:true});
document.addEventListener('touchend',e=>{let dy=e.changedTouches[0].clientY-startY;if(dy < -45){if(!unlocked)unlock();else if(!ccOpen)openCC()}else if(dy>60&&unlocked&&startY<65){openCC()}else if(dy>60&&ccOpen)closeCC()},{passive:true});
$('gestureZone').addEventListener('click',()=>unlocked?lockPhone():unlock());
$('closeCC').onclick=closeCC;$('ccHome').onclick=closeCC;
$('flashLock').onclick=()=>say('Flashlight demo');$('cameraLock').onclick=()=>say('Camera demo');
document.querySelectorAll('[data-toggle]').forEach(b=>b.addEventListener('click',()=>{b.classList.toggle('active');say((b.querySelector('small')?.textContent||'Setting')+' toggled')}));
$('brightness').addEventListener('input',e=>{document.querySelector('.wallpaper').style.filter=`brightness(${e.target.value/85}) saturate(1.15)`});
$('volume').addEventListener('input',()=>{});
$('playPause').onclick=()=>{$('playPause').textContent=$('playPause').textContent==='▶'?'Ⅱ':'▶';say('Media demo')};
document.querySelectorAll('.app').forEach(b=>b.onclick=()=>say(b.dataset.app+' is a visual demo'));
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&ccOpen)closeCC();if(e.key===' '){e.preventDefault();unlocked?openCC():unlock()}});
