iOS STYLE PHONE — ANDROID WEB APP

This is an iPhone-inspired visual launcher/demo with a lock screen, home screen and Control Center.
It is a web app, not an actual iOS system replacement. Android does not allow an ordinary app to replace
the real system Control Center or secure lock screen completely.

HOW TO USE
1. Extract the ZIP.
2. Open index.html in Chrome on your Android phone.
3. For a home-screen shortcut, open the browser menu and choose "Add to Home screen" if available.
4. Swipe up to unlock the demo. Swipe down from the top area or swipe up again to show Control Center.
5. Tap the demo toggles and adjust brightness to test the interface.

For best installable-PWA behavior, host these files on an HTTPS website first. Buttons are visual demos;
they do not switch your phone's real Wi-Fi, Bluetooth, mobile data, flashlight, or screen recording.
